# Lexi AI
Personal AI assistant (single-file web app).

Live: https://YOUR-USERNAME.github.io/lexi/
